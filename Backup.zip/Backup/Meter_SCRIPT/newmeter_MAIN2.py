import requests
import json
import psycopg2
import os
import datetime
import time

# --- Configuration ---
MDMS_API_URL = 'http://localhost:8094/egov-mdms-service/v1/_search'
MDMS_TENANT_ID = 'pb'  # Tenant for MDMS search (State Level)
BILLING_TENANT_ID = 'pb.phagwara'  # Tenant for Billing API & DB (ULB Level)
API_ENDPOINT = 'http://localhost:8083/ws-calculator/meterConnection/_create?'
AUTH_TOKEN = '056b0775-bf53-4167-82ed-3cbd4dd6e9a7'
# SEARCH_API_TOKEN is not used in the final script

# Database Configuration (using environment variables with fallbacks)
dbname = os.getenv("DB_NAME", "Phagwara")
dbuser = os.getenv("DB_USER", "postgres")
dbpassword = os.getenv("DB_PASSWORD", "postgres")
host = os.getenv("DB_HOST", "localhost")


# --------------------------------------------
# 1. Fetch MDMS Billing Periods
# --------------------------------------------
def fetch_mdms_tax_periods():
    """Fetches Tax Periods from MDMS and filters for WS Quarterly periods."""
    print("⏳ Fetching MDMS Tax Periods...")
    mdms_payload = {
        "RequestInfo": {
            "apiId": "Rainmaker", "ver": ".01", "action": "_fetchBill", "msgId": "20170310130900|en_IN",
            "authToken": AUTH_TOKEN,
            "userInfo": {
                "id": 3494375, "userName": "EMP-PATIALA-MIGRATOR", "name": "RU1QLVBBVElBTEEtTUlHUkFUT1I=",
                "type": "EMPLOYEE", "mobileNumber": "OTgxOTk5OTk5OQ==", "tenantId": "pb.patiala",
                "uuid": "8127b8d4-8e14-44e8-aa9b-b39577c56650"
            }
        },
        "MdmsCriteria": {
            "tenantId": MDMS_TENANT_ID,
            "moduleDetails": [{"moduleName": "BillingService", "masterDetails": [{"name": "TaxPeriod"}]}]
        }
    }

    try:
        response = requests.post(MDMS_API_URL, json=mdms_payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        tax_periods = data.get('MdmsRes', {}).get('BillingService', {}).get('TaxPeriod', [])

        filtered_periods = {
            # Use 'code' as the key for easy lookup
            p['code']: {"fromDate": p['fromDate'], "toDate": p['toDate'], "service": p['service'],
                        "periodCycle": p['periodCycle']}
            for p in tax_periods
            if p.get('service') == 'WS' and p.get('periodCycle') == 'QUATERLY'
        }
        return filtered_periods

    except requests.exceptions.RequestException as e:
        print(f"🔥 Error fetching MDMS data: {e}")
        return {}


# --------------------------------------------
# Configuration & DB Setup
# --------------------------------------------
MDMS_PERIODS = fetch_mdms_tax_periods()

if not MDMS_PERIODS:
    print("🚨 MDMS periods could not be fetched. Script cannot proceed.")
    exit()

try:
    connection_db_ws = psycopg2.connect(
        dbname=dbname, user=dbuser, password=dbpassword, host=host
    )
    cur = connection_db_ws.cursor()
    print(f"✅ Database connection established to {dbname} on {host}.")
except psycopg2.Error as e:
    print(f"🛑 Database connection error: {e}")
    exit()


# --------------------------------------------
# 2. Function to find all missing quarters
# --------------------------------------------
def get_missing_quarters(last_billed_date_str, current_reading_date_epoch, mdms_periods):
    """
    Finds all WS QUARTERLY periods between the day after the last billed date
    and the current reading date (inclusive of the current reading date's entire day).
    """
    if not last_billed_date_str:
        # If never billed, start from the earliest period found in MDMS
        last_billed_epoch_boundary = 0
    else:
        try:
            # Convert 'DD-MM-YYYY' to a date object
            last_billed_date = datetime.datetime.strptime(last_billed_date_str, "%d-%m-%Y")

            # Set the boundary to 00:00:00 of the day *after* the last billed date.
            # E.g., if last billed was 31-03-2025, the boundary is 01-04-2025.
            next_day_date = last_billed_date + datetime.timedelta(days=1)
            last_billed_epoch_boundary = int(next_day_date.timestamp() * 1000)

        except ValueError:
            print(f"⚠️ Invalid date format for last billed date: {last_billed_date_str}")
            return []

    missing_quarters = []

    # Iterate through all MDMS periods to find those that fit the gap
    for code, period in mdms_periods.items():
        period_end_date_epoch = period['toDate']

        # Check if the period START is after the boundary,
        # and the period END is on or before the current reading date's inclusive boundary.
        if period['fromDate'] >= last_billed_epoch_boundary and period_end_date_epoch <= current_reading_date_epoch:
            missing_quarters.append((period['fromDate'], code))

    # Sort by start date (epoch) to ensure sequential billing
    missing_quarters.sort(key=lambda x: x[0])
    return [code for epoch, code in missing_quarters]


# --------------------------------------------
# 3. Handle Meter Status and API Call
# --------------------------------------------
def handle_meter_status(json_data, status, previous_meter_reading, current_meter_reading,
                        last_reading_date_epoch, current_reading_date_epoch_qtr, billing_period_str):
    """Constructs payload and calls the ws-calculator API."""

    # Safely convert readings to float/int
    try:
        current_meter_reading = float(current_meter_reading)
    except (ValueError, TypeError):
        current_meter_reading = 0.0

    try:
        previous_meter_reading = float(previous_meter_reading)
    except (ValueError, TypeError):
        previous_meter_reading = 0.0

    payload = {
        "RequestInfo": {
            "apiId": "Rainmaker", "ver": ".01", "action": "", "did": "1", "key": "",
            "msgId": "20170310130900|en_IN", "requesterId": "", "authToken": AUTH_TOKEN,
            "userInfo": {
                "id": 3288460, "userName": "EMP-Phagwara-MIGRATOR", "name": "EMP-Phagwara-MIGRATOR",
                "gender": "MALE", "mobileNumber": "9459286077", "active": True, "type": "EMPLOYEE",
                "tenantId": BILLING_TENANT_ID,
                "roles": [
                    {"code": "WS_DOC_VERIFIER", "name": "WS Document Verifier", "tenantId": BILLING_TENANT_ID},
                    {"code": "SW_DOC_VERIFIER", "name": "SW Document Verifier", "tenantId": BILLING_TENANT_ID}
                ],
                "uuid": "e596bfcc-9331-4306-af2b-d1162b463263"
            }
        },
        "meterReadings": {
            "currentReadingDate": current_reading_date_epoch_qtr,
            "currentReading": current_meter_reading,
            "billingPeriod": billing_period_str,
            "meterStatus": status,
            "connectionNo": json_data['id_no'],
            "lastReading": previous_meter_reading,
            "lastReadingDate": last_reading_date_epoch,
            "tenantId": BILLING_TENANT_ID,
            "generateDemand": True
        }
    }

    headers = {
        'Content-Type': 'application/json',
        # Assuming this static bearer token is a valid system-to-system auth header
        'Authorization': 'Bearer ZWdvdi11c2VyLWNsaWVudDplZ292LXVzZXItc2VjcmV0',
    }

    try:
        response = requests.post(API_ENDPOINT, json=payload, headers=headers, timeout=30)
        response_text = response.text
    except requests.exceptions.RequestException as e:
        response_code = 500
        response_text = f"Request Exception: {e}"
        print(f"   ❌ Request Error for {json_data['id_no']} | Period: {billing_period_str}: {response_text}")
        return response_code

    response_code = response.status_code
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    connection_no = json_data['id_no']

    if response_code == 200:
        print(f"   ✅ Success for {connection_no} | Status: {status} | Period: {billing_period_str}")
    else:
        print(f"   ❌ Failed for {connection_no} | Status: {status} | Period: {billing_period_str}: {response_code}")
        # Update the DB with the failure for the last attempted billing period
        cur.execute("""
            UPDATE meter_billing
            SET response_code = %s, ismigrationdate = %s, response = %s
            WHERE id_no = %s
        """, (str(response_code), now, response_text, connection_no))
        connection_db_ws.commit()

    return response_code


# --------------------------------------------
# 4. Main Processing Loop (Multi-Quarter Logic)
# --------------------------------------------
sql_query = """
    SELECT row_to_json(cd) 
    FROM meter_billing AS cd 
    WHERE cd.id_no='1014022063'; 
"""

print(f"📖 Executing DB Query to find connections to process...")
cur.execute(sql_query)
data_row = cur.fetchall()

print(f"Found {len(data_row)} connections to process.")

for row in data_row:
    json_data = row[0]
    connection_no = json_data['id_no']
    db_prev_mtr_dt_str = json_data.get('prev_mtr_dt')  # Last billed date (e.g., 31-03-2025)
    db_curr_mtr_dt_str = json_data.get('curr_mtr_dt')  # New reading date (e.g., 30-09-2025)

    # Prepare common connection data
    db_prev_rdg = json_data.get("prev_rdg")
    db_curr_rdg = json_data.get("curr_rdg")
    db_is_locked = json_data.get("islocked", "FALSE") in ["True", "TRUE"]
    db_is_dead = json_data.get("isdead", "FALSE") in ["True", "TRUE"]
    db_no_meter = db_prev_rdg == "N"

    # Convert DB current reading date (DD-MM-YYYY) to epoch
    try:
        db_curr_date_dt = datetime.datetime.strptime(db_curr_mtr_dt_str, "%d-%m-%Y")

        # 🌟 CORRECTED LOGIC: Add one day to the date object to make the boundary inclusive.
        # This fixes the issue of missing the final quarter that ends on db_curr_mtr_dt.
        next_day_date = db_curr_date_dt + datetime.timedelta(days=1)
        current_reading_date_epoch = int(next_day_date.timestamp() * 1000)

    except (ValueError, TypeError):
        print(f"⛔ Skipping {connection_no}: Invalid curr_mtr_dt '{db_curr_mtr_dt_str}'")
        continue

    print(f"\n🔄 Processing: {connection_no} (Last Billed: {db_prev_mtr_dt_str}, Current Read: {db_curr_mtr_dt_str})")

    # Get the list of quarters that need billing
    quarters_to_bill_codes = get_missing_quarters(
        db_prev_mtr_dt_str,
        current_reading_date_epoch,
        MDMS_PERIODS
    )

    if not quarters_to_bill_codes:
        print(f"   ✅ No missing quarters found. Skipping.")
        continue

    print(f"   📝 Found {len(quarters_to_bill_codes)} missing quarters: {quarters_to_bill_codes}")

    # Set up initial reading state for the loop.
    previous_reading_for_next_quarter = db_prev_rdg

    # Loop through and bill each missing quarter sequentially
    for i, current_code in enumerate(quarters_to_bill_codes):
        is_last_quarter = (i == len(quarters_to_bill_codes) - 1)
        current_period_data = MDMS_PERIODS[current_code]

        # A. Dates for the API call
        # last_reading_date_epoch is the START of the current quarter
        last_reading_date_epoch = current_period_data["fromDate"]
        # current_reading_date_epoch_qtr is the END of the current quarter
        current_reading_date_epoch_qtr = current_period_data["toDate"]

        # Format dates for billingPeriod string (e.g., 01/01/2024-31/03/2024)
        prev_date = datetime.datetime.fromtimestamp(last_reading_date_epoch / 1000).strftime("%d/%m/%Y")
        current_date = datetime.datetime.fromtimestamp(current_reading_date_epoch_qtr / 1000).strftime("%d/%m/%Y")
        # billing_period_str = prev_date + "-" + current_date
        billing_period_str = prev_date + " - " + current_date  # Note the space-hyphen-space

        # B. Reading values and status
        previous_reading = previous_reading_for_next_quarter
        current_reading = previous_reading  # Default reading for Assessed/Locked/Dead

        # --- 1. Check for perpetually non-working meter states ---
        if db_no_meter:
            meter_status = "No-meter"
            previous_reading = 0.0
            current_reading = 0.0
        elif db_is_locked:
            meter_status = "Locked"
            current_reading = previous_reading
        elif db_is_dead:
            meter_status = "Breakdown"
            current_reading = previous_reading

        # --- 2. Check for Working/Assessed Status (only if meter is functional) ---
        elif is_last_quarter:
            # Final quarter: Use the actual reading and status
            meter_status = "Working"
            current_reading = db_curr_rdg

            # Handle non-numeric readings for the final quarter (treat as no change)
            if isinstance(current_reading, str) and not (current_reading.replace('.', '', 1).isdigit()):
                print(
                    f"      ⚠️ Final reading non-numeric ('{db_curr_rdg}'). Setting current reading to previous reading ({previous_reading}).")
                current_reading = previous_reading
        else:
            # Intermediate quarter: Use 'Assessed' status (equal readings = flat charge)
            meter_status = "Assessed"
            current_reading = previous_reading

        # 4. Call the billing handler
        print(
            f"      -> Billing {current_code} | Status: {meter_status} | Last R: {previous_reading} | Current R: {current_reading}")

        response_code = handle_meter_status(
            json_data,
            meter_status,
            previous_reading,
            current_reading,
            last_reading_date_epoch,
            current_reading_date_epoch_qtr,
            billing_period_str
        )

        # 5. Update state for the next quarter's iteration
        if response_code == 200:
            # The current reading of the quarter just billed becomes the previous reading for the next one.
            previous_reading_for_next_quarter = current_reading
        else:
            # If billing fails for any quarter, stop the sequence for this connection
            print(f"      🛑 Billing failed for {current_code}. Stopping sequence for {connection_no}.")
            break

# --------------------------------------------
# Cleanup
# --------------------------------------------
cur.close()
connection_db_ws.close()
print("✅ Multi-quarter billing script completed and database connection closed.")